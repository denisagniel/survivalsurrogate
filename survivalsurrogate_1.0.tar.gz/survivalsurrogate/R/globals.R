utils::globalVariables(c(
  "Q0_1", "Q1_1", "Q_s", "Q_y", "bind_cols", "boot_estimate", "eif", 
  "estimand", "estimate", "gamma_part", "include_in_training", "muQ", 
  "muQstar", "pi_part", "pistar_part", "plugin_est", "plugin_se", 
  "pred", "se", "static_part", "wt_j"
))
